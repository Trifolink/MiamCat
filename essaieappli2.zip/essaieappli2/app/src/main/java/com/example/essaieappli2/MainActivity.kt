package com.example.essaieappli2

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.essaieappli2.AccueilActivity
import android.view.animation.AnimationUtils

class MainActivity : AppCompatActivity() {

    private val duree: Long = 5000
    private lateinit var imageView: ImageView
    private lateinit var textView: TextView

    private lateinit var topanim: android.view.animation.Animation
    private lateinit var bottomanim: android.view.animation.Animation

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        setContentView(R.layout.activity_main)

        imageView = findViewById(R.id.logo)
        textView = findViewById(R.id.slogan)

        topanim = AnimationUtils.loadAnimation(this, R.anim.animation_top)
        bottomanim = AnimationUtils.loadAnimation(this, R.anim.animation_bot)

        imageView.startAnimation(topanim)
        textView.startAnimation(bottomanim)

        Handler().postDelayed({
            val intent = Intent(this@MainActivity, AccueilActivity::class.java)
            startActivity(intent)
            finish()
        }, duree)
    }
}
